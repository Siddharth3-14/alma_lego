
The original ALMA Cycle 6 configurations files can be downloaded here:

https://almascience.nrao.edu/tools/casa-simulator

##### Reference:
- [ALMA Proposer's Guide](https://almascience.nrao.edu/documents-and-tools/cycle5/alma-proposers-guide) Appendix A.
- https://casaguides.nrao.edu/index.php/Antenna_List
