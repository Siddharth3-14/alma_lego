#! /usr/bin/env python
"""Dependencies for the Virtual Interferometer Application."""
__all__ = ['util_tk',
           'vriCalc']
